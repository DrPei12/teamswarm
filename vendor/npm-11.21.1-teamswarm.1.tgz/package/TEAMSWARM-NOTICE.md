# npm runtime distributed with TeamSwarm

Based on npm 11.21.1; replaces bundled ip-address 10.7.2 with the unmodified upstream 10.7.4 package for GHSA-rxp7-6hxx-x8q5. The npm version identifies this distribution.

npm source and these modifications are redistributable under Artistic-2.0. Bundled dependencies retain their licenses. Upstream notices are preserved.

Sources and reproduction: https://github.com/DrPei12/teamswarm/tree/main/vendor
npm: https://registry.npmjs.org/npm/-/npm-11.21.1.tgz
ip-address: https://registry.npmjs.org/ip-address/-/ip-address-10.7.4.tgz
