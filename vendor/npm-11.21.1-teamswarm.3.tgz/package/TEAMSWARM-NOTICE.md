# npm runtime distributed with TeamSwarm

Based on npm 11.21.1, with pinned unmodified upstream packages:

- ip-address 10.7.4
- undici 6.29.1
- glob 14.0.2
- minimatch 11.0.1
- path-scurry 3.0.0
- @isaacs/nonrecursive-glob-match 1.0.1

Bundled package manifests reference the updated glob and minimatch versions.

npm source and these modifications are redistributable under Artistic-2.0. Bundled dependencies retain their licenses. Upstream notices are preserved.

Sources and reproduction: https://github.com/DrPei12/teamswarm/tree/main/vendor
npm: https://registry.npmjs.org/npm/-/npm-11.21.1.tgz
ipAddress: https://registry.npmjs.org/ip-address/-/ip-address-10.7.4.tgz
undici: https://registry.npmjs.org/undici/-/undici-6.29.1.tgz
glob: https://registry.npmjs.org/glob/-/glob-14.0.2.tgz
minimatch: https://registry.npmjs.org/minimatch/-/minimatch-11.0.1.tgz
pathScurry: https://registry.npmjs.org/path-scurry/-/path-scurry-3.0.0.tgz
nonrecursiveGlobMatch: https://registry.npmjs.org/@isaacs/nonrecursive-glob-match/-/nonrecursive-glob-match-1.0.1.tgz
