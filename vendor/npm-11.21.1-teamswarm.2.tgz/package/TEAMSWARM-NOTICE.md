# npm runtime distributed with TeamSwarm

Based on npm 11.21.1, with unmodified upstream ip-address 10.7.4 and undici 6.29.1. These replace bundled ip-address 10.7.2 and undici 6.29.0.

npm source and these modifications are redistributable under Artistic-2.0. Bundled dependencies retain their licenses. Upstream notices are preserved.

Sources and reproduction: https://github.com/DrPei12/teamswarm/tree/main/vendor
npm: https://registry.npmjs.org/npm/-/npm-11.21.1.tgz
ipAddress: https://registry.npmjs.org/ip-address/-/ip-address-10.7.4.tgz
undici: https://registry.npmjs.org/undici/-/undici-6.29.1.tgz
